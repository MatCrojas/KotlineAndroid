<?php

class Controller
{

    function __construct()
    {
        //echo "<p> Controller template </p>";
        $this->view = new View();
    }
}
