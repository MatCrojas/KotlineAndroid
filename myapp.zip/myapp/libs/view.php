<?php

class View
{

    function __construct()
    {
       // echo "<p> View template </p>";
    }

    function render($viewName)
    {
        require 'views/'.$viewName.'.php';
    }

}
