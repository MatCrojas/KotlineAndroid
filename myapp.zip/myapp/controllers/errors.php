<?php
class Errors extends Controller
{
    function __construct()
    {
        parent::__construct();
        $this->view->message = 'Error message from controller to view';
        $this->view->render('errors/index');
        echo "<p>Error loading requested resource...</p>";
    }
}